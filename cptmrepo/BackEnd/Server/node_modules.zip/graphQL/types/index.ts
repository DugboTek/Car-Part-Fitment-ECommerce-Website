import { CarPart } from "./carPartType.js";

export { CarPart } from "./carPartType.js";
