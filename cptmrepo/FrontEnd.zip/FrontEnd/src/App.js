//import logo from './logo.svg';
import './App.css';
import React from 'react';
import { ChakraProvider } from '@chakra-ui/react';
import MainLogo from './Components/NavComponents/MainLogo'
import Navbar from './Components/NavComponents/Navbar';
import Footer from './Components/Footer';
import AccountMenu from './Components/NavComponents/AccountMenu';
import Cart from './Components/NavComponents/Cart';
import SearchBar from './Components/NavComponents/SearchBar';
import SortBy from './Components/ResultsPage/SortBy';
import Garage from './Components/Garage/Garage';
// import ItemSpecs from './Components/QuickView/modal';
import Results from './Components/ResultsPage/Results';
import ItemSpecs from './Components/QuickView/modal';
import ResultsPage from './Components/ResultsPage/ResultsCards';
import Facets from './Components/ResultsPage/FacetsBox';
import ProductImage from './Components/ProductPage/ProductImage';


function App() {
  return (
    <ChakraProvider>
      <div className="App">
        <ProductImage/>
        <Facets/>

      {/* <MainLogo/>
      <SearchBar/>
      <Cart/>
      <AccountMenu/>
      <Navbar/>
      <br/>
      <SortBy/>
      <Facets/>
       <Footer/> */}
      </div>
    </ChakraProvider>
  );
}

export default App;


