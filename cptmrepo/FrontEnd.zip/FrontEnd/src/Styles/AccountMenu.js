// import url('https://fonts.googleapis.com/css2?family=Bagel+Fat+One&family=Kanit:ital,wght@0,300;0,400;0,600;1,300&display=swap');

// import { extendTheme } from "@chakra-ui/react";
// import "@fontsource/dancing-script";

// const theme = extendTheme({
//   fonts: {
//     myFont1: "Dancing Script",
//     myFont2: "Times New Roman",
//   },
// });

// export default theme;