// Ali Moulton

// feedbacK:
// change search bar button to dark polaris blue
import React from 'react';
import {Input, InputGroup, InputLeftElement, Button, Text } from '@chakra-ui/react';
import { SearchIcon } from '@chakra-ui/icons';
//import Autosuggest from 'react-autosuggest';

import "../../Styles/main.css";
import "../../Styles/NavStyles/SearchBar.css";


function SearchBar() {
    const searchRef = React.useRef();

    const showSuggestions = (e) => {
        // if(document.querySelector('#search-input').value !== '') {
            searchRef.current.classList.toggle("hide-suggestions");
        // }else if(e.key == backspace){
        //     toggle
        // }
    };

    const [value, setValue] = React.useState('');
    const updateSearch = (event) => setValue(event.target.value);
    //need to toggle show-suggestions
    // const suggestion1 = 'Air filters';
    // const suggestion2 = 'Air ports';
    return (
            <InputGroup className="search-bar">
                <div className='complete-container'>
                    <div className='search-container'>
                        {/* <InputLeftElement pointerEvents='none'>
                            <SearchIcon color='gray.300' />
                        </InputLeftElement> */}
                        
                        <Input 
                            value = {value}
                            onChange={updateSearch}//check if the key is enter within this function
                            onClick={showSuggestions}
                            id="search-input"
                            type="search" 
                            placeholder='Search by product name, category, brand, or part number. '
                        
                        />
                        <div ref={searchRef} className =  "suggestions hide-suggestions">
                            <ul>
                                <li href='/#'>
                                    {value}
                                </li>
                                <li href='/#'>
                                    {value}
                                </li>
                                <li href='/#'>
                                    {value}
                                </li>
                            </ul>
                           
                        </div>
                    </div>
                    <div className='btn-container'>
                        <Button 
                            onClick={generateSearch} 
                            className="search-btn" 
                            // colorScheme='blue'  
                            color="white" 
                            bg='#004E97'
                        > Search
                        </Button>
                    </div>
                </div>
                
            </InputGroup>
    );
}

function generateSearch() {
    const searchVal = document.querySelector("#search-input").value;
    console.log(searchVal);
}

export default SearchBar;