// Ali Moulton
import {
    Button,
    // Menu,
    // MenuButton,
    // MenuList,
    // MenuItem,
    // MenuItemOption,
    // MenuOptionGroup,
    MenuDivider,
 
    IconButton
  } from '@chakra-ui/react'
import "../../Styles/main.css"
import "../../Styles/Cart.css"
import React from 'react';
import { SunIcon, HamburgerIcon } from '@chakra-ui/icons'
import CartIcon from '../../Images/carticon.png';


  function Cart() 
  {
    const quantity = 0;
    const [currentItems, setCurrentItems] = React.useState(quantity);
    const addToCart = () => {
      setCurrentItems((prevValue) => prevValue + 1);
      // changeIcon();
    }
    const removeFromCart = () => {
      if(currentItems >= 1){
        setCurrentItems((prevValue) => prevValue - 1)
      }
    }
    // const changeIcon() {
    //   icon = document.getElementById(".icon");
    //   icon.style.width = 10px;
    //   revertIcon()
    // }

    // const revertIcon(){

    // }

    return(
      <div className='cart-and-btn'>

        <div className='cart cart-container'>
          <div className='icon'>
            <img src={CartIcon} alt="shopping cart" />
          </div>
          <div className='quant-text'>
            <p id='quant'>{currentItems}</p>
          </div>
        </div>
        <br></br>
        <br></br>

        <div className='add-btn'>
          <Button
            onClick={addToCart}
          >Add </Button>
        </div>
        <div className='rem-btn'>
          <Button
            onClick={removeFromCart}
          >Remove </Button>
        </div>
      </div>

    );

  }

  function addToCart(count){
    return count++;
  }

 export default Cart;