// Ali Moulton

import {useRef} from "react";
import {FaBars, FaTimes} from "react-icons/fa"
import "../../Styles/main.css";
import "../../Styles/NavStyles/Navbar.css";
// import DownArrow from '../Images/down-arrow.png';
import SpaceFiller from '../../Images/transparent.png';

function Navbar() {
    const navRef = useRef();

    const showNavbar = () => {
        navRef.current.classList.toggle("responsive_nav");
    };

    return (
        <header>
            <img src={SpaceFiller} alt="Polaris Logo" width="50px" />

            <nav ref={navRef}>
                    <a href="/#"> </a>
                    <a href="/#"> </a>
                    <a href="/#"> MY GARAGE</a>
                    {/* <a href="/#" className="hamburger-hidden"> GARAGE</a> */}
                    <a href="/#"> CATEGORIES</a>
                    <a href="/#"> VEHICLES </a>
                    <a href="/#">CONTACT US</a>
                    <a href="/#" className="nav-hidden"> MY ACCOUNT</a>
                    <a href="/#" className="nav-hidden"> CART</a>
                <button className="nav-btn nav-close-btn" onClick={showNavbar}>
                    <FaTimes/>
                </button>
            </nav>
            <button className="nav-btn hamburger-nav" onClick={showNavbar}>
                <FaBars/>
            </button>

        </header>
     );
}
export default Navbar;