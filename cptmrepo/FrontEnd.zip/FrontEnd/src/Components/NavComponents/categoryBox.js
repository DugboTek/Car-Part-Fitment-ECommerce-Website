import {
    Popover,
    PopoverTrigger,
    PopoverContent,
    PopoverHeader,
    PopoverBody,
    PopoverFooter,
    PopoverArrow,
    PopoverCloseButton,
    PopoverAnchor,
  } from '@chakra-ui/react'
import { Button, ButtonGroup } from '@chakra-ui/react'

export default function categoryBox() {
    return (
            <Popover placement='top-start'>
            <PopoverTrigger>
                <Button>Click me</Button>
            </PopoverTrigger>
            <PopoverContent>
                <PopoverHeader fontWeight='semibold'>Popover placement</PopoverHeader>
                <PopoverArrow />
                <PopoverCloseButton />
                <PopoverBody>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore.
                </PopoverBody>
            </PopoverContent>
            </Popover>
    );
}
