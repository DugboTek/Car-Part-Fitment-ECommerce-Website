// Ali Moulton

import LogoImg from '../../Images/polaris-logo.png';
import "../../Styles/main.css";
import "../../Styles//NavStyles/MainLogo.css";

function MainLogo() {
    return (
        <div className="logo main-logo">
            <img src={LogoImg} alt="Polaris Logo" height="30px" />
        </div>
    );
}

export default MainLogo;