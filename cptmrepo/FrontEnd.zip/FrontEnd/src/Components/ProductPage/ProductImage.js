import React from 'react';
import PinchZoomPan from "react-image-zoom-pan";
import '../../Styles/ProductPage/ProductImage.css'
 
function ProductImage () {
        return (
            <div className='img-container'>
            <div style={{ width: "100%", height: "500px" }}>
              <PinchZoomPan 
                maxScale='5' 
                position='center' 
                zoomButtons='true' 
                doubleTapBehavior='zoom' 
                >
                <img alt="{products[0].Type" src={products[0].imgsrc} />
              </PinchZoomPan>
            </div>
            </div>
          );
        };
export default ProductImage;

let products = [
    {
        "Type": "Air Filter", 
        "Number": "100301",
        "Price" : "19.99",
        "imgsrc" : "https://th.bing.com/th/id/R.9f4b7a15cfa61fee19671fa634fe140c?rik=7FUEDiXpM6Y7%2fg&pid=ImgRaw&r=0"
    },
    {
        "Type": "Premium Air Filter", 
        "Number": "08091999 ",
        "Price" : "9.99",
        "imgsrc" : "https://i5.walmartimages.com/asr/0eb4bd2e-608b-4f6c-9f19-fdd5f9b4fa9f.5e8dd33dfc7157de8d46d2e0ea87c7c3.jpeg?odnWidth=1000&odnHeight=1000&odnBg=ffffff"
    },
    {
        "Type": "Volvo Air Filter Pack", 
        "Number": "01182011 ",
        "Price" : "119.99",
        "imgsrc" : "https://th.bing.com/th/id/OIP.2FWxNo7YTNUVRGWgQmJN5gHaE7?pid=ImgDet&w=800&h=533&rs=1"

    },
    {
        "Type": "O'Reilly Filters", 
        "Number": "67554321 ",
        "Price" : "19.79",
        "imgsrc" : "https://th.bing.com/th/id/OIP.PeWR27LdvhOCOhaBbDCk_AAAAA?pid=ImgDet&w=320&h=320&rs=1"

    },
    {
        "Type": "Air Filter replacement pack", 
        "Number": "07061970",
        "Price" : "14.99",
        "imgsrc" : "https://th.bing.com/th/id/OIP.ZT6W8poe0agzmFHu5OLupgHaHa?pid=ImgDet&w=750&h=750&rs=1"

    },
    {
        "Type": "OEM Filter Cleaners", 
        "Number": "02171973",
        "Price" : "19.99",
        "imgsrc" : ""

    },
    {
        "Type": "Donovan Air Filters", 
        "Number": "76549871 ",
        "Price" : "19.99",
        "imgsrc" : ""

    }
];