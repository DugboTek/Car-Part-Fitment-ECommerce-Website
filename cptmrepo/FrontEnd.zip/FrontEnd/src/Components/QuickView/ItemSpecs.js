import { Grid, GridItem } from '@chakra-ui/react'
import { Box } from '@chakra-ui/react'
import { ChevronRightIcon, ChevronLeftIcon, StarIcon, CheckIcon, ArrowUpDownIcon } from '@chakra-ui/icons'
import { Text } from '@chakra-ui/react'
import { Button } from '@chakra-ui/react'
import { Image } from '@chakra-ui/react'
import React, { useState } from 'react'
import { Input } from '@chakra-ui/react'


export function ItemSpecs ({background}) {

    const heartoff = new URL('https://th.bing.com/th/id/R.9f27f9e5650e0d582760cd6b9e04ce2a?rik=X74gfvNu9JDnrA&riu=http%3a%2f%2fcdn.onlinewebfonts.com%2fsvg%2fimg_56734.png&ehk=v0zkOQmQp%2bSFUb3AvAmD4mTd%2ffaH1CWUImU7fYELFeg%3d&risl=&pid=ImgRaw&r=0');
    const hearton = new URL('https://th.bing.com/th/id/OIP.yHflGASc9dliE2qjqOlfiAHaGV?pid=ImgDet&rs=1');
    const heartImages = {heartoff, hearton};
    const [heart, setHeart] = useState(true);

    const [value, setValue] = React.useState('')
    const handleChange = (event) => setValue(event.target.value)

    const partOne = new URL('https://www.zoro.com/static/cms/product/full/Emery%20Jensen%20Distribution%20LLC_8008302xxA.epsxxMaxxx426969.jpeg');
    const partTwo = new URL('https://th.bing.com/th/id/R.1e798bcdc2bda6e28a5996c6f6f36db1?rik=2XnrYkGlvUMvUA&pid=ImgRaw&r=0');
    const partImages = {partOne, partTwo};
    const [part, setPart] = useState('false');

    const [close, setClose] = useState('false');

    const heartChangeHandler = () => {
        if(!heart) {
            setHeart(true);
        }else{
            setHeart(false)
        }
    };

    var partNumber = 1;

    var property = {
        imageUrl: 'https://th.bing.com/th/id/R.1e798bcdc2bda6e28a5996c6f6f36db1?rik=2XnrYkGlvUMvUA&pid=ImgRaw&r=0',
        imageAlt: 'Picture of a Car',
        currPicNum: 1,
        endingPicNum: 2,
        heartStatus: "https://cdn.onlinewebfonts.com/svg/img_573153.png",
    }

    
    const partChangeHandler = () => {
        if(!part) {
            partNumber = partNumber + 1;
            setPart(true);
        }else{
            partNumber = partNumber - 1;
            setPart(false);
        }
    }

    return (

        <div>
        <Grid
    h='30em'
    w='30em'
    templateRows='repeat(3, 1fr)'
    templateColumns='repeat(2, 1fr)'
    gap={5}
    >
        <GridItem rowSpan={3} colSpan={1} bg={background}>
            <br/>
            <br/>
            <br/>
            <Image src={!part ? partImages.partOne : partImages.partOne } alt={property.imageAlt}/>
            <br/>
            <br/><br/><br/>
            <Grid templateColumns="repeat(4, 1fr)" color="black" fontSize="1.5em" gap={0}>
                    <Box w="100%" h="10"/>
                    <Box w="100%" h="10"><ChevronLeftIcon onClick={partChangeHandler}/></Box>
                    <Box w="100%" h="10">{!part ? '1/1' : '1/1'}</Box>
                    <Box w="100%" h="10" ><ChevronRightIcon onClick={partChangeHandler}/></Box>
            </Grid>

        </GridItem>

        <GridItem colSpan={1} gap={3} bg={background}>
            <Grid templateColumns="repeat(1, 1fr)" gap={1}>
                <Box w="100%" h="10" bg={background} /> 
                <Box w="100%" h="10" bg={background} >
                    <Grid templateColumns="repeat(5, 1fr)" gap={0}>
                        <Text fontSize='25px' as='b'>PARTXX </Text>
                        <Box w="100%" h="10" bg={background} />
                        <Box w="100%" h="10" bg={background} />
                        <Image src={!heart ? heartImages.heartoff : heartImages.hearton } alt='heart-button' onClick={heartChangeHandler}/>
                    </Grid>
                </Box>

                <Box w="100%" bg={background} >
                        <Grid templateColumns='repeat(1, 1fr)'gap={0}>
                            <Grid templateColumns='repeat(9, 1fr)'gap={0}>
                                <GridItem w='100%' bg={background} >
                                <StarIcon/>
                                </GridItem>
                                <GridItem w='100%' bg={background} >
                                <StarIcon/>
                                </GridItem>
                                <GridItem w='100%' bg={background} >
                                <StarIcon/>
                                </GridItem>
                                <GridItem w='100%' bg={background} >
                                <StarIcon/>
                                </GridItem>
                                <GridItem w='100%' bg={background} >
                                <StarIcon/>
                                </GridItem>
                                <GridItem w='100%' bg={background} color='black'> (26)</GridItem>
                                <GridItem w='100%' bg={background} color='black'/>
                                <GridItem w='100%' bg={background} color='black'/>
                                <GridItem w='100%' bg={background} color='black'/>
                            </Grid>
                            <GridItem w='100%' bg={background} color='black'><Box w="100%" h="10" bg={background} ><Text as='ins'>Brand Name</Text></Box></GridItem>
                        </Grid>    
                </Box>

                <Box w="100%" h="10" bg={background} >
                    <Grid templateColumns='repeat(2, 1fr)' gap={6}>
                        <Box w="100%" h="7" textAlign={'left'} bg={background} color='black' fontSize='20px' fontWeight={'bold'}><h>$45.23</h></Box>
                        <Grid templateColumns='repeat(2, 1fr)'>
                            <GridItem w='100%' h='50%' bg={background}>  <Image boxSize='40px' h='25px' src='https://th.bing.com/th/id/R.baba532ecb397d4766aa0c80d3c38c1b?rik=VaRaCJpv02P1eg&riu=http%3a%2f%2fcdn.onlinewebfonts.com%2fsvg%2fimg_518646.png&ehk=V18Mv7nDxORRnEnLaZ789P%2b2NOrrAgTOftQn9mXhwMA%3d&risl=&pid=ImgRaw&r=0'/></GridItem>
                            <GridItem>Ships.. </GridItem>
                        </Grid>
                    </Grid>
                </Box>
                <Box w="100%" h="100px" bg={background} paddingTop='10px'>
                    <Text as='i'>Random Text this is the coolest description ever, buy our cars yay, blah blah blah bla </Text>
                </Box>
                <Box w="100%" h="10" bg={background} >
                    <Grid templateColumns='repeat(3, 1fr)' padding='2px' gap={2}>
                            <GridItem w='100%' h='10'>
                            <Button w='120px' colorScheme='blue'>Add to Cart</Button>
                            </GridItem>

                            <GridItem>
                                <Grid templateColumns="repeat(3, 1fr)" color='#A9A9A9' border='2px' gap={0}>
                                    <Box color='#A9A9A9' border='1px'w='9' h="10" bg="white"> <Text paddingBottom= '10px' color='black' paddingLeft= '5px' fontSize={'26'} >-</Text></Box>
                                    <Box color='#A9A9A9' border='1px'w='9' h="10" bg="white"><Input type='number' value={value} onChange={handleChange} htmlSize={1} width='35px' /></Box>
                                    <Box color='#A9A9A9' border='1px' w='9' h="10" bg="white" ><Text paddingBottom= '10px' color='black' paddingLeft= '5px' fontSize={'26'} >+</Text></Box>
                                </Grid>
                            </GridItem>
                            {/* <GridItem w='100%' h='10' bg='white' color='black' alignContent={'right'} textAlign={'right'}>
                            {/* <Input type='number' value={value} onChange={handleChange} htmlSize={1} width='55px' /> <Text fontSize={'15'} >Quantity </Text>  */}
                            {/* </GridItem>
                            <GridItem w='100%' h='10'> */}
                            {/* <ArrowUpDownIcon width='20px' height='20px'/> */}
                            {/* </GridItem> */}
                    </Grid>

                </Box>
                <Box w="100%" h="10" bg={background} >
                    <Grid templateColumns='repeat(1, 1fr)' gap={2}>

                            <GridItem w='100%' h='7px' textAlign='left' color='black' fontSize='0.8em' paddingBottom='10px' paddingTop='40px'>
                                                Guarenteed Fit
                            </GridItem>

                            <GridItem alignText={'left'} w='100%' h='3.5em' bg='#E4E3E3' >
                                <Grid templateColumns='repeat(4, 1fr)' gap={0}>
                                    <GridItem alignText={'left'} w='70%' h='15' bg='#E4E3E3' >
                                        <CheckIcon padding='5px' height='40px' width='40px' color='#28CA4B'/>
                                    </GridItem>
                                    <GridItem alignText={'left'} colSpan="3" fontSize={'15'} w='100%' h='15' paddingTop='5px' ><Text as='b'>PART FITS!</Text> <Text as='i'>2021 Ford F-250 Super Duty 6'8"</Text></GridItem>
                                </Grid>    
                            
                            </GridItem>
                    </Grid>

                </Box>
            </Grid>
        </GridItem>

    </Grid>
    </div>
    );
}

export default ItemSpecs;