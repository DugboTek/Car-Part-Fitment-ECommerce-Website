import "../../Styles/GarageStyles/Garage.css";
import React from 'react';
import { Box } from '@chakra-ui/react';
import GarageDoor from './GarageDoor.js';
import GarageBox from './GarageBox.js';
import { Image } from '@chakra-ui/react';

export function Garage () {

    const property = {
        backGround: 'black',
        textColor: 'red',
        garageImage: new URL('https://cdn0.iconfinder.com/data/icons/logistics-glyph-5/64/Warehouse-256.png'),
        gImageALT: 'image of a garage',
        height: '33em',
        width: '27em'
    }

    return (
    <Box className="background" borderRadius="md" padding='1em' height = '35em' overflow='hidden' width='30em' >
    <div className="pair">
        <div className="roll-out">
        <GarageBox garageHeight = {property.height} garageWidth= {property.width} className="front"></GarageBox>
        <br/>
        <GarageDoor garageHeight = {property.height} garageWidth= {property.width} className="back"></GarageDoor>
        </div>
    </div>
    </Box>);
}

export default Garage;