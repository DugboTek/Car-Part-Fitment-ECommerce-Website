// Feedback

// do we want uppercase?
//Garage door should open opposite direction


import { Box } from '@chakra-ui/react'
import { Image } from '@chakra-ui/react'
import {
    Menu,
    MenuButton,
    MenuList,
    MenuItem
  } from '@chakra-ui/react'
  import { Button } from '@chakra-ui/react'
  import { ChevronDownIcon } from '@chakra-ui/icons'
  import { Grid, GridItem } from '@chakra-ui/react'
import { Tabs, TabList, TabPanels, Tab, TabPanel } from '@chakra-ui/react'

export function GarageBox ({garageHeight, garageWidth}) {

    const property = {
        imageUrl: 'https://th.bing.com/th/id/R.5e1141681888156a9e93e4c6d9e98c40?rik=fgc9vmE40Ex4GA&riu=http%3a%2f%2fimages4.fanpop.com%2fimage%2fphotos%2f22300000%2fRandom-Cars-autorev-22326979-1400-930.jpg&ehk=roZQycUHRW8gQZm8Ei6LRlD7%2b1ur8Pdlz5orpuRAj5Q%3d&risl=&pid=ImgRaw&r=0',
        imageAlt: 'Picture of a Car',
        backGround: 'white',
        textColor: 'white'
    }

    var myCars = [
        { name: "Honda Accord 2005", make: "Honda", model: "hybrid", year: 2000 },
        { name: "Toyota Tacoma Truck 2000", make: "Toyota", model: "SUV", year: 1999 },
        { name: "Ram 3000", make: "prius", model: "single rider", year: 2020 }
      ];

    var buttonLabel = {
        currentCar : 'Cars in the Garage',
        make : 'Make',
        model : 'Model',
        year : 'Year'
    }

    return(

    <div>
    <Box width = {garageWidth} height={garageHeight} borderWidth='1px' borderRadius='lg' overflow='hidden' bg={property.backGround}>

        <Box
        bg = {property.backGround}
        fontWeight='bold'
        letterSpacing='wide'
        fontSize='2em'
        textTransform='uppercase'
        paddingTop='40px'
        paddingBottom='90px'
        ml='2'
        textAlign='center'
        padding='4'
        >
        My Garage
        </Box>
        <Tabs isFitted variant='soft-rounded' paddingLeft='20px' colorScheme='blue'width='90%'>
        <TabList tlineHeight='5px'color='black' mb='1em'>
            <Tab fontWeight={'50px'} fontSize={'1xl'}>CARS</Tab>
            <Tab fontWeight={'50px'} fontSize={'1xl'}>ADD CAR</Tab>
        </TabList>
        <TabPanels >
            <TabPanel alignContent='center' paddingLeft='3em'>
                    <Menu>
                    {({ isOpen }) => (
                        <>
                        <MenuButton transition='all 0.2s' width='15em' borderRadius='md'borderWidth='0.2em' _hover={{ bg: 'gray.400' }} _expanded={{ bg: 'blue.400' }}
            _focus={{ boxShadow: 'outline' }} isActive={isOpen} as={Button} rightIcon={<ChevronDownIcon />}>
                            {isOpen ? 'Select from my garage' : buttonLabel.currentCar}
                        </MenuButton>
                        <MenuList>
                            {myCars.map((car) => (
                                <MenuItem onClick={() => buttonLabel.currentCar = car.name}>{car.name}</MenuItem>
                            ))}
                        </MenuList>
                        </>
                    )}
                    </Menu>

                <Box paddingTop='20px' boxSize='380px'> 
                 <Image width='20em' src={property.imageUrl} alt={property.imageAlt} />  
                </Box>
            </TabPanel>

            <TabPanel alignContent='center' paddingLeft='3em'>
                <Box>
                <Grid templateColumns='repeat(1, 1fr)' gap={3}>
                <GridItem>
                <Menu>
                    {({ isOpen }) => (
                        <>
                        <MenuButton transition='all 0.2s' width='20em' borderRadius='md'borderWidth='0.2em' _hover={{ bg: 'gray.400' }} _expanded={{ bg: 'blue.400' }}
            _focus={{ boxShadow: 'outline' }} isActive={isOpen} as={Button} rightIcon={<ChevronDownIcon />}>
                            {isOpen ? 'Choose A Year' : buttonLabel.year}
                        </MenuButton>
                        <MenuList>
                            <MenuItem onClick={() => buttonLabel.year = '2010'}>2010</MenuItem>
                            <MenuItem onClick={() => buttonLabel.year = '2009'}>2009</MenuItem>
                            <MenuItem onClick={() => buttonLabel.year = '2007'}>2007</MenuItem>
                            <MenuItem onClick={() => buttonLabel.year = '2005'}>2005</MenuItem>
                        </MenuList>
                        </>
                    )}
                </Menu>
                </GridItem>
                <GridItem>
                <Menu>
                    {({ isOpen }) => (
                        <>
                        <MenuButton transition='all 0.2s' width='20em' borderRadius='md'borderWidth='0.2em' _hover={{ bg: 'gray.400' }} _expanded={{ bg: 'blue.400' }}
            _focus={{ boxShadow: 'outline' }} isActive={isOpen} as={Button} rightIcon={<ChevronDownIcon />}>
                            {isOpen ? 'Choose A Make' : buttonLabel.make}
                        </MenuButton>
                        <MenuList>
                            <MenuItem onClick={() => buttonLabel.make = 'Ford'}>Ford</MenuItem>
                            <MenuItem onClick={() => buttonLabel.make = 'Nissan'}>Nissan</MenuItem>
                            <MenuItem onClick={() => buttonLabel.make = 'Tesla'}>Tesla</MenuItem>
                        </MenuList>
                        </>
                    )}
                </Menu>
                </GridItem>
                <GridItem>
                    <Menu>
                            {({ isOpen }) => (
                                <>
                                <MenuButton transition='all 0.2s' width='20em' borderRadius='md'borderWidth='0.2em' _hover={{ bg: 'gray.400' }} _expanded={{ bg: 'blue.400' }}
                    _focus={{ boxShadow: 'outline' }} isActive={isOpen} as={Button} rightIcon={<ChevronDownIcon />}>
                                    {isOpen ? 'Choose A Current Model' : buttonLabel.model}
                                </MenuButton>
                                <MenuList>
                                    <MenuItem onClick={() => buttonLabel.model = 'subcompact'}>subcompact</MenuItem>
                                    <MenuItem onClick={() => buttonLabel.model = 'compact SUV'}>compact SUV</MenuItem>
                                </MenuList>
                                </>
                            )}
                    </Menu>
                </GridItem>
                <GridItem>
                <Button onClick={() => myCars.push({name: (buttonLabel.make + ' / ' + buttonLabel.year), make: buttonLabel.make, model: buttonLabel.model, year: buttonLabel.year})} colorScheme='blue'>+ NEW CAR</Button>
                </GridItem>
                </Grid>

                </Box>
            </TabPanel>
        </TabPanels>
        </Tabs>
        <Box p='6'>
        </Box>

    </Box>
    </div>);
  };
  
  export default GarageBox;