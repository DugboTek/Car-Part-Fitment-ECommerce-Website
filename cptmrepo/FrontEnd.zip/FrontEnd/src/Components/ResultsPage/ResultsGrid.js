import '../../Styles/ResultsPageStyles/ResultsGrid.css'
import React from 'react';

import ResultsPage from './ResultsCards';

function ResultsGrid() {
    return(
        <div className='results-grid'>
            <ResultsPage/>
        </div>
    );

}

export default ResultsGrid;