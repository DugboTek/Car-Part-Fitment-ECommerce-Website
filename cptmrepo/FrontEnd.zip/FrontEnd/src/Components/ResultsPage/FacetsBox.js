import React from 'react';
import {Stack, Checkbox, CheckboxGroup } from '@chakra-ui/react';
import '../../Styles/ResultsPageStyles/FacetsBox.css'


function FacetsBox() {
    return(
        <div className='facets'>
           {facets.map(facet => {
                let facetNames = facet.Facet
                return(
                    <div className='cat-list' key={facet}> 
                        <h1>{facet.Category} </h1>
                        {makeList(facetNames)}
                    </div>
                    
                )})
            } 
        </div>
    );
  
}


function makeList(facet) {
    return (
        <Stack className='facet-list' direction='column'>
            {facet.map(facet => {
                let facetCount = facet.fcount
                facetCount = 13
                return(
                <Checkbox 
                onChange= {(e) =>
                {recordFacet(e)}}
                 key={facet}> {facet} ({facetCount})</Checkbox>)}
            )}
        </Stack>
    )

}

let facets= [
    {
        'Category': 'Brand', 
        'Facet': ['Honda', 'Volvo', 'OEM']
    }, 

    {
        'Category': 'Year', 
        'Facet' : ['2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023']
    }, 
    {
        'Category': 'Size', 
        'Facet' : ['Small', 'Medium', 'Large']
    }
];



// i think i need to use states here -
// look into useCheckbox hook via chakras website

function recordFacet(e) {
 // THIS IS WRONG
    console.log(e);
    console.log(e.target);

    if(e.target===true) {

        addFacet(e.target.value)
    }else{
        removeFacet(e.target.value)
    }
    updateFacets()
}
function addFacet(facet) {
    console.log('add');
}
function removeFacet(facet) {
    console.log('remove');
}
function updateFacets() {
    console.log('this function should update the search query based on the changed facets');
}
export default FacetsBox;